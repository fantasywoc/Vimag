var searchData=
[
  ['of_20xml_0',['Get information out of XML',['../_example_3.html',1,'']]],
  ['out_20of_20xml_1',['Get information out of XML',['../_example_3.html',1,'']]]
];
